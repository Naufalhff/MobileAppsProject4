package com.example.pertemuan_1hanyarunrun.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryColor = Color(0xFF6200EE)
val PrimaryVariant = Color(0xFF3700B3)
val SecondaryColor = Color(0xFF03DAC5)
val DangerColor = Color(0xFFD32F2F)
val SuccesColor = Color(0xFF4CAF50)